criaCartao(
    'Messi',
    'Quantas champions tem o messi ?',
    'Tem 4 champions '
)

criaCartao(
    'CR7',
    'Quantos gols tem CR7?',
    'Tem 900 gols '
)

criaCartao(
    'Campeonato Paulista ',
    'Quem ganhou mais paulistão?',
    'Corinhitians'
)

criaCartao(
    'Campeonato Paulista ',
    'Qual  time que ganhou mais champions e qual ganhou mais libertadores ?',
    'Real madrid ganhou mais champions e o  Indepiendiente ganhou mais libertadores'
)